var APP_DATA = {
  "scenes": [
    {
      "id": "0-auenansicht",
      "name": "Außenansicht",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1824,
      "initialViewParameters": {
        "yaw": -0.030223626004154625,
        "pitch": -1.4181903366921809,
        "fov": 1.290348174345596
      },
      "linkHotspots": [
        {
          "yaw": 0.14553925237299126,
          "pitch": 0.46557177515968107,
          "rotation": 6.283185307179586,
          "target": "1-virtuelle-tour-starten"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-virtuelle-tour-starten",
      "name": "Virtuelle Tour starten",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1824,
      "initialViewParameters": {
        "yaw": 0.08852212058068076,
        "pitch": 0.11106179581565989,
        "fov": 1.290348174345596
      },
      "linkHotspots": [
        {
          "yaw": 0.05668599150189202,
          "pitch": 0.2842790510172186,
          "rotation": 0,
          "target": "2-eingangsbereich"
        },
        {
          "yaw": -3.040041055541261,
          "pitch": 0.35827826351919967,
          "rotation": 5.497787143782138,
          "target": "0-auenansicht"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-eingangsbereich",
      "name": "Eingangsbereich",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1824,
      "initialViewParameters": {
        "yaw": 0.09745549395825215,
        "pitch": 0.3450032594641055,
        "fov": 1.290348174345596
      },
      "linkHotspots": [
        {
          "yaw": 0.5936384102806844,
          "pitch": 0.6088875816723487,
          "rotation": 0.7853981633974483,
          "target": "3-sofa-lounge"
        },
        {
          "yaw": -0.4323797914944798,
          "pitch": 0.4180452372825094,
          "rotation": 0,
          "target": "4-empfangsbereich"
        },
        {
          "yaw": 2.4781349610977816,
          "pitch": 0.6034678409192011,
          "rotation": 0,
          "target": "1-virtuelle-tour-starten"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-sofa-lounge",
      "name": "Sofa-Lounge",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1824,
      "initialViewParameters": {
        "yaw": -0.1421136733734656,
        "pitch": 0.2852295387700359,
        "fov": 1.290348174345596
      },
      "linkHotspots": [
        {
          "yaw": 1.122069415342457,
          "pitch": 0.37526552898227905,
          "rotation": 0,
          "target": "2-eingangsbereich"
        },
        {
          "yaw": 2.707739236728667,
          "pitch": 0.47158370746014455,
          "rotation": 0,
          "target": "4-empfangsbereich"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-empfangsbereich",
      "name": "Empfangsbereich",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1824,
      "initialViewParameters": {
        "yaw": 1.764676377114693,
        "pitch": 0.19852691176549264,
        "fov": 1.290348174345596
      },
      "linkHotspots": [
        {
          "yaw": -0.15021771816058482,
          "pitch": 0.4745689072900614,
          "rotation": 0,
          "target": "3-sofa-lounge"
        },
        {
          "yaw": 0.6107061220807086,
          "pitch": 0.26396670506282405,
          "rotation": 0,
          "target": "2-eingangsbereich"
        },
        {
          "yaw": -3.047739587824557,
          "pitch": 0.2799882151183777,
          "rotation": 0,
          "target": "5-kursbereich-a"
        },
        {
          "yaw": -2.51027922362543,
          "pitch": 0.04310909520938111,
          "rotation": 1.5707963267948966,
          "target": "7-toilette"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 1.8076277297976855,
          "pitch": 0.03615220867789759,
          "title": "Willkommen im...<br>",
          "text": "MiriFlows Yogastudio Bad Urach<br>"
        }
      ]
    },
    {
      "id": "5-kursbereich-a",
      "name": "Kursbereich A",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1824,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.6515179849062136,
          "pitch": 0.4243875715744885,
          "rotation": 0,
          "target": "6-kursbereich-b"
        },
        {
          "yaw": 2.0147159996615063,
          "pitch": 0.03821601593583068,
          "rotation": 4.71238898038469,
          "target": "7-toilette"
        },
        {
          "yaw": 2.9158755817373008,
          "pitch": 0.3139979851534669,
          "rotation": 0,
          "target": "4-empfangsbereich"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.009166543291229345,
          "pitch": 0.3335430394182062,
          "title": "Mehr Infos unter:<br>",
          "text": "https://www.miriflows.de/"
        }
      ]
    },
    {
      "id": "6-kursbereich-b",
      "name": "Kursbereich B",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1824,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.5204803189818108,
          "pitch": 0.4443161144678953,
          "rotation": 0,
          "target": "5-kursbereich-a"
        },
        {
          "yaw": -1.3303503530454233,
          "pitch": -0.0055448440343397465,
          "rotation": 4.71238898038469,
          "target": "7-toilette"
        },
        {
          "yaw": -0.7018978180096891,
          "pitch": 0.19305764006339032,
          "rotation": 0.7853981633974483,
          "target": "4-empfangsbereich"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "7-toilette",
      "name": "Toilette",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1824,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "MiriFlows Yogastudio Bad Urach",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": false
  }
};
